def preprocessing(text,path):
    ######## считываем из базы формул #####
    lst_gl=[]
    f=open(path+"\\Files\\formulas_.txt","r",encoding="utf-8")
    for line_ in f:
        lst_gl.append(line_.strip())
    f.close()
   
    lst=[]
    str1=""
    str2=""
    match=0

    for i in range(len(text)):
            if text[i]=="{":
                match=match+1

            if text[i]=="}":
                match=match-1
                str1=str1+text[i]
             
            if match>0:
                str1=str1+text[i]
           
            if match==0:
                if text[i]!="}":
                    str2=str2+text[i]

                if str1!="":
                    if not str1 in lst_gl:
                        lst.append(str1)
                        lst=list(set(lst))
                        str2=str2+"formula_"+str(len(lst)+len(lst_gl))
                    else:
                        for k in range(len(lst_gl)):
                            if lst_gl[k]==str1:
                                str2=str2+"formula_"+str(k+1)
                str1=""

    f=open(path+"\\Files\\formulas_.txt","a",encoding="utf-8")
    for i in range(len(lst)):
            print(lst[i])
            f.write(lst[i]+'\n')
    f.close()
  
    return str2

def combine_formula_and_text_f(l,fl):
    for i,elem in enumerate(l):
        if not isinstance(elem,str):
            l[i]=combine_formula_and_text_f(elem,fl)
        else:
            if "formula" in l[i]:
                t=int(l[i].split("_")[1])-1
                l[i]=fl[t]
          
    return l

def combine_formula_and_text(formula,path):
    f=open(path+"\\Files\\config.ini","r",encoding="utf-8")
    for line in f:
        line=line.split(':')
        if line[0]=="Formulas_razbor":
                lst_=line[1].strip()
                break
    f.close()
    
    ######## считываем из базы формул #####
    lst_gl=[]
    f=open(path+"\\Files\\"+lst_,"r",encoding="utf-8")
    for line_ in f:
        lst_gl.append(eval(line_.strip()))
    f.close()

    r=combine_formula_and_text_f(formula,lst_gl)
    return r



