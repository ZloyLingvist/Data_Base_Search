from ranger import *
from processing import *
from stamford import *
import os

path = os.path.dirname(os.path.dirname(__file__))
test_dir_path=path+"\\Test\\"

def testing_block_one(f1,f2,outname):
    '''f1-файл со ответами'''
    f=open(test_dir_path+f1,"r",encoding="utf-8")
    a=[]
    b=[]
    for line in f:
        if line!='\n':
            a.append(eval(line.strip()))   
    f.close()

    '''f2-файл с разборами'''
    f=open(test_dir_path+f2,"r",encoding="utf-8")
    b=[]
    for line in f:
         if line!='\n':
             b.append(eval(line.strip()))
    f.close()

    res=[]
    for i in range(len(a)):
        try:
            A=Stamford()
            B=Ranger()
            r=A.main(b[i],1)
            r1=B.main(a[i],r,2)
            b[i]=combine_formula_and_text(r,path)
   
            r2=B.main(a[i],b[i],2)
            res.append([str(i+1),r1,r2])
        except:
            res.append([str(i+1),-1,-1])

    f=open(test_dir_path+outname,"w",encoding="utf-8")
    for x in res:
        f.write(str(x)+'\n')

    f.close()
   

testing_block_one("test_lst.txt","test_in.txt","outname.txt")        
    

    
